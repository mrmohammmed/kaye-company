/*global $*/

$(document).ready(function () {

    'use strict';

    var scrollButton,
        src,
        atr;

    scrollButton = $("#scroll-top");

    $(window).scroll(function () {
        if ($(this).scrollTop() >= 500) {
            scrollButton.show();
        } else {
            scrollButton.hide();
        }

    });

    $('.smallimage').click(function () {
        src = $(this).attr('src');
        $('.upper').html('<img src="' + src + '" />');
    });


    scrollButton.click(function () {
        $("html,body").animate({
            scrollTop: 0
        }, 600);
    });
    
    atr = 0;
    $('a').click(function () {
        atr = $(this).attr('href');
        $('html, body').animate({
            scrollTop: $(atr).offset().top
        }, 1400);
        return false;
    });

    $('#owl-demo').owlCarousel({
        autoplay: true,
        rtl: true,
        loop: true,
        margin: 30,
        nav: false,
        dots: true,
        navText: false,
        transitionStyle: true,
        autoplayTimeout: 10000,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            1000: {
                items: 3
            }
        }
    });

    $("#owl-clients").owlCarousel({

        autoPlay: true, //Set AutoPlay to 3 seconds
        rtl: true,
        ltr: true,
        loop: true,
        autoplay: true,
        dots: false,
        responsive: {
            0: {
                items: 1,
                nav: false
            },

            600: {
                items: 2,
                nav: false
            },
            1000: {
                items: 5
            }
        },
        nav: false,
        navText: ["<i class='fa fa-angle-right fa-lg'></i>", "<i class='fa fa-angle-left fa-lg'></i>"],
        margin: 5

    });

    $(".filter-button").click(function () {
        var value = $(this).attr('data-filter');

        if (value === "all") {
            //$('.filter').removeClass('hidden');
            $('.filter').show('1000');
        } else {
            //            $('.filter[filter-item="'+value+'"]').removeClass('hidden');
            //            $(".filter").not('.filter[filter-item="'+value+'"]').addClass('hidden');
            $(".filter").not('.' + value).hide('3000');
            $('.filter').filter('.' + value).show('3000');

        }
    });

    if ($(".filter-button").removeClass("active")) {
        $(this).removeClass("active");
    }
    $(this).addClass("active");

    // Instantiate MixItUp:
    $('#Container').mixItUp();

    // Team Slider
    $('.autoplay').slick({
        dots: true,
        infinite: false,
        speed: 300,
        slidesToShow: 2,
        slidesToScroll: 3,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
            // You can unslick at a given breakpoint now by adding:
            // settings: "unslick"
            // instead of a settings object
        ]
    });


});
